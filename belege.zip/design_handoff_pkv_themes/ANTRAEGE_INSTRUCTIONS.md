# Implementierungsanweisung: Anträge-Seite (Beihilfe-Anträge)

## Ziel

Implementiere die neue Anträge-Seite als Master-Detail-Layout. Die Referenzimplementierung befindet sich in `Anträge.html` (High-Fidelity Prototyp). Übertrage das Design in die bestehende Codebase unter Verwendung vorhandener Patterns, Komponenten und Routing-Mechanismen.

---

## Datenmodell

```
Antrag
├── id, nr, titel, status, stelle
├── erstellt: Date
├── versendet: Date | null
├── rechnungen: Rechnung[]        (1:n)
└── bescheide: Bescheid[]         (1:n — Widersprüche möglich!)
    └── Bescheid
        ├── id, typ, datum, gesamtbetrag
        └── positionen: Position[]
            ├── rechnungId
            ├── tatsaechlicheKosten: number | null
            ├── anerkannt: number | null
            └── abgelehnt: boolean
```

**Wichtige Beziehungen:**
- Ein Antrag kann mehrere Rechnungen enthalten
- Ein Antrag kann mehrere Bescheide haben (Erstbescheid → Widerspruchsbescheid → …)
- Bescheid-Typen: `'Erstbescheid'` | `'Widerspruchsbescheid'`
- Ältere Bescheide (nicht der letzte) gelten als „überschrieben" und werden visuell gedimmt (`opacity: 0.6`)

---

## Layout

```
┌─────────────────────────────────────────────────────────────────┐
│  NAV (46px, immer dunkel)                                       │
├──────────────────────┬──────────────────────────────────────────┤
│  LISTE (360px fest)  │  DETAIL (flex: 1)                        │
│                      │                                          │
│  Header              │  Header (fest, kein Scroll)              │
│  Filter-Dropdown     │  ├ Nr + Status-Badge(s)                  │
│  ─────────────────── │  ├ Titel (h2, 18px)                      │
│  Antrag-Cards        │  ├ Institution                           │
│  (scrollbar)         │  ├ Betrag + Anzahl Rechnungen            │
│                      │  └ Bearbeiten-Button                     │
│                      │                                          │
│                      │  Scrollbarer Body                        │
│                      │  ├ Workflow-Stepper (interaktiv)         │
│                      │  ├ Rechnungen-Sektion                    │
│                      │  └ Bescheide-Sektion (1:n)               │
└──────────────────────┴──────────────────────────────────────────┘
```

---

## Komponenten

### 1. Listenkarte (AntragCard)

```
padding: 12px 16px
borderLeft: 3px — transparent (default) | var(--primary) (aktiv)
background:  transparent → var(--row-hover) (hover) → var(--row-active) (aktiv)

Zeile 1:  #nr (10px, text-subtle, bold) + StatusBadge(status) + ggf. StatusBadge('Widerspruch')
Zeile 2:  Titel (13px, 600) links  |  Gesamtbetrag rechts (13px, 700)
          Institution (10px, text-subtle)  |  BH-Betrag rechts (10px, grün/rot)
Zeile 3:  "Erstellt DD.M.YYYY · Versendet DD.M.YYYY"  +  "N Bescheide" (teal/amber)
```

**Wann wird „Widerspruch" Badge gezeigt?**
→ `antrag.bescheide.some(b => b.typ === 'Widerspruchsbescheid')`

**BH-Betrag Farbe:**
→ `gesamtbetrag > 0` → `--green` | sonst → `--rose`

**Bescheid-Zähler Farbe:**
→ `bescheide.length > 1` → `--amber` (Widerspruch!) | `bescheide.length === 1` → `--teal`

---

### 2. Status-Badges

```
Entwurf:        bg: --surface-hi    text: --text-muted   border: --border
Versendet:      bg: --blue-dim      text: --blue         border: rgba(blue, .3)
In Bearbeitung: bg: --amber-dim     text: --amber        border: rgba(amber, .3)
Beschieden:     bg: --green-dim     text: --green        border: rgba(green, .3)
Widerspruch:    bg: --rose-dim      text: --rose         border: rgba(rose, .3)
Archiviert:     bg: --surface-hi    text: --text-subtle  border: --border

Stil: font-size 10px, font-weight 700, padding 2px 8px, border-radius 20px
```

---

### 3. Workflow-Stepper (Interaktiv!)

**Schritte in Reihenfolge:**
`['Entwurf', 'Versendet', 'In Bearbeitung', 'Beschieden', 'Archiviert']`

**Visueller Zustand pro Schritt:**

| Zustand  | Kreis-BG          | Kreis-Farbe | Label-Farbe    | Inhalt |
|----------|-------------------|-------------|----------------|--------|
| Vergangenheit | --green-dim  | --green     | --text-muted   | ✓     |
| Aktuell  | --primary         | #fff        | --primary      | Nr.    |
| Zukunft  | --surface-alt     | --text-subtle | --text-subtle | Nr.   |

**Verbindungslinien:**
- Breite: 20px, Höhe: 2px, margin-bottom: 22px (vertikal zentriert mit dem Kreis)
- Vergangen: `--green` | Zukünftig: `--border`

**Interaktion — Klick auf zukünftigen Schritt:**

1. Zeige inline Bestätigungs-Card **direkt unter dem Stepper**
2. Card: `background: --bg`, blauer Ring (`box-shadow: 0 0 0 3px --primary-dim`), Border in `--primary`
3. Inhalt: "Status wechseln zu **[Schritt]**" + optional Datum + Buttons

**Schritte die ein Datum verlangen:** `['Versendet', 'In Bearbeitung', 'Beschieden']`

```
Bestätigungs-Card Layout:
  [Status-Text] [Datum-Label + Input (type="date", vorbelegt: heute)] [Abbrechen] [Bestätigen]
  → alles in einer Flex-Zeile, wrapping bei kleinem Platz

Abbrechen: bg --surface-alt, border --border, color --text-muted
Bestätigen: bg --primary, color #fff, font-weight 600
```

**Verhalten:**
- Bestätigen → Status wechselt, Card verschwindet, Stepper aktualisiert sich
- Abbrechen → Card verschwindet, Status bleibt

---

### 4. Rechnungen-Sektion

```
Header: "RECHNUNGEN (N)" — 10px, bold, --text-subtle, letter-spacing 0.07em

Pro Rechnung (border-top: 1px solid --row-border, padding 7px 0):
  [R-XXXX (primary, 10px, bold, 48px min)]  [Betrag (13px, bold, 70px rechts)]  [Person · Erbringer (muted)]  [Entfernen (rose)]

+ Rechnung hinzufügen... → Select, volle Breite, bg: --bg
```

---

### 5. Bescheide-Sektion

```
Header-Zeile:
  Links:  "BESCHEIDE" (10px label) + "N Bescheide" (12px) + ggf. "Widerspruch eingereicht" Badge (amber)
  Rechts: "+ Bescheid" Button (--primary)

Wenn keine Bescheide: Dashed-Border-Box mit Hinweistext
```

**BescheidCard:**

```
border: 1px solid --border, border-radius: 10px
opacity: 0.6 wenn isOverridden (nicht der letzte Bescheid, wenn mehrere vorhanden)

Akzentfarben:
  Erstbescheid:        --teal   (Punkt + Summenfarbe)
  Widerspruchsbescheid: --amber  (Punkt + Summenfarbe)

Card-Header (surface-alt, collapsible):
  [farbiger Punkt 8px] [Typ-Name, 13px bold] [ggf. "überschrieben" Badge] [Datum] [Betrag] [∧/∨]

Card-Body (surface):
  Positionen-Tabelle:
    Spalten: RECHNUNG | TATSÄCHL. KOSTEN | ANERKANNT (BH) | ABGELEHNT
    Header:  9px, font-weight 700, letter-spacing 0.06em, --text-subtle
    Zeilen:
      Rechnung-Spalte:    R-XXXX (primary, bold) · Betrag (text-subtle)
      Kosten-Spalte:      Betrag (text-muted) oder "—" (text-subtle)
      Anerkannt-Spalte:   Betrag in --green, bold — oder "—"
      Abgelehnt-Spalte:   "✗" in --rose, bold — oder "—"
    Summe-Zeile:          border-top, Label bold, Anerkannt-Summe in Akzentfarbe

  Validierung: "✓ Summe stimmt mit Bescheid überein" in --green, 11px

  Rechnung-Zuordnen-Select (volle Breite, bg: --bg)

  Footer-Zeile:
    Links: "BESCHEID-DOKUMENT" (9px label) + [⊙ Abfotografieren] [↑ PDF hochladen]
    Rechts: [Löschen] (--rose, plain button)
```

---

## Theme-Tokens (Chalk = Light, Carbon = Dark)

Vollständige Tokens stehen in `README.md` des Handoff-Pakets. Hier die wichtigsten:

### Chalk (Light)
```css
--bg: #EDEAE3; --surface: #F8F5F0; --surface-alt: #EDE9E2; --surface-hi: #E4DED6;
--border: #D4CEC6; --text: #1C1914; --text-muted: #6A6258; --text-subtle: #A09888;
--nav: #1E1C18;   /* Nav ist immer dunkel! */
--primary: #2B5CE8; --green: #1A9E58; --amber: #C87820; --rose: #D84060; --teal: #189E8A;
--row-hover: rgba(0,0,0,0.025); --row-active: rgba(43,92,232,0.07); --row-border: rgba(0,0,0,0.07);
```

### Carbon (Dark)
```css
--bg: #181818; --surface: #212121; --surface-alt: #292929; --surface-hi: #323232;
--border: #3E3E3E; --text: #EBEBEB; --text-muted: #888888; --text-subtle: #555555;
--nav: #101010;
--primary: #00C4B0; --green: #4EC87A; --amber: #E8A030; --rose: #F06070; --teal: #00C4B0;
--row-hover: rgba(255,255,255,0.025); --row-active: rgba(0,196,176,0.08); --row-border: rgba(255,255,255,0.05);
```

**Theme-Aktivierung:**
```js
// Beim App-Start
const saved = localStorage.getItem('pkv-theme');
const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
document.documentElement.setAttribute('data-theme', saved || (prefersDark ? 'carbon' : 'chalk'));
```

---

## Navigation

```
Nav-Höhe: 46px
Hintergrund: immer --nav (dunkel, alle Themes)
Nav-Text: rgba(255,255,255,0.9) für aktiv, rgba(255,255,255,0.42) für inaktiv
Aktiver Tab: font-weight 600 + border-bottom: 2px solid --primary
Aktiver Tab in dieser View: "Anträge"
```

---

## Referenzdatei

→ `Anträge.html` — vollständiger, lauffähiger Prototyp. Im Browser öffnen, Tweaks-Button oben rechts für Theme-Wechsel.

---

## Hinweis

Die HTML-Datei ist ein **Design-Referenz-Prototyp** — kein Produktionscode. Die Aufgabe ist, dieses Design in der bestehenden App-Architektur neu zu implementieren, unter Verwendung der dort etablierten Patterns (Routing, State-Management, Komponenten-Library etc.).
