# Implementierungsanweisung: Anträge-Seite v3
**PKV-Abrechnung · Beihilfe & PKV-Antragsmanagement**

---

## Überblick

Die Anträge-Seite ist die zentrale Arbeitsfläche für das Einreichen und Verfolgen von Beihilfe- und PKV-Anträgen. Sie zeigt eine Master-Detail-Ansicht: links eine filterbare Antragsliste, rechts die vollständige Detailansicht mit Workflow-Stepper, Rechnungszuordnung und Bescheid-Erfassung.

**Referenzdatei:** `Anträge v3.html` — High-Fidelity Prototyp, im Browser öffnen. Tweaks-Button (Toolbar) zum Theme-Wechsel zwischen Chalk (hell) und Carbon (dunkel).

---

## Fidelity

**High-Fidelity.** Pixel-genaue Umsetzung erwünscht. Farben, Abstände, Animationen und Interaktionen sind final. Die HTML-Datei ist ein Design-Referenz-Prototyp — kein Produktionscode. In der bestehenden App-Architektur (React, Vue, native etc.) neu implementieren.

---

## Datenmodell

```typescript
type AntragTyp    = 'Beihilfe' | 'PKV';
type AntragStatus = 'Entwurf' | 'Versendet' | 'In Bearbeitung' | 'Beschieden' | 'Archiviert';

interface Antrag {
  id:            string;           // intern, z.B. 'A-0001'
  nr:            string;           // Anzeige, z.B. '#0001'
  typ:           AntragTyp;
  titel:         string | null;    // optional, Fallback: 'Kein Titel'
  stelle:        string;           // z.B. 'Bundesverwaltungsamt', 'HUK Coburg'
  status:        AntragStatus;
  erstellt:      string;           // 'DD.MM.YYYY'
  versendet:     string | null;    // gesetzt wenn Status → Versendet
  notiz:         string;
  paperlessLink: string;           // URL zu Paperless NGX, leer wenn nicht verknüpft
  rechnungen:    string[];         // Referenzen auf Rechnungs-IDs
  bescheide:     Bescheid[];       // 1:n — mehrere durch Widerspruch möglich
}

interface Bescheid {
  id:            string;
  typ:           'Erstbescheid' | 'Widerspruchsbescheid';
  datum:         string;           // 'DD.MM.YYYY'
  aktenzeichen:  string;           // leer wenn noch nicht bekannt
  gesamtbetrag:  number;           // Gesamtbetrag laut Bescheid (Kontrollfeld)
  notiz:         string;
  positionen:    BescheidPosition[];
}

interface BescheidPosition {
  rId:       string;               // Referenz auf Rechnungs-ID
  kosten:    number | null;        // tatsächliche Kosten laut Bescheid
  anerkannt: number;               // anerkannter Betrag
  abgelehnt: number;               // = kosten - anerkannt
  grund:     string;               // Ablehnungsgrund, leer wenn vollständig anerkannt
}

interface Rechnung {
  id:        string;
  betrag:    number;
  person:    string;
  erbringer: string;
  datum:     string;
  typ:       string;               // 'Arzt' | 'Apotheke' | 'Krankenhaus' | ...
  bhOffen:   boolean;              // noch nicht bei Beihilfe eingereicht
  pkvOffen:  boolean;              // noch nicht bei PKV eingereicht
}
```

**Wichtige Geschäftsregeln:**
- Ein Antrag kann mehrere Bescheide haben (Erst → Widerspruch → …)
- Ältere Bescheide (nicht der letzte) gelten als „überschrieben" (`opacity: 0.55`)
- Rechnungen beim Hinzufügen filtern: nur solche anzeigen, die für diesen Antrag-Typ noch nicht eingereicht wurden
- `Erstattungsquote = sum(anerkannt) / sum(tatsächliche Kosten)` des letzten Bescheids

---

## Layout

```
┌─────────────────────────────────────────────────────────────────────┐
│  NAV (46px, immer dunkel in beiden Themes)                          │
├──────────────────────┬──────────────────────────────────────────────┤
│  LISTE (372px fest)  │  DETAIL (flex: 1)                            │
│                      │                                              │
│  Header              │  Fester Header (kein Scroll)                 │
│  ├ Titel + Button    │  ├ Badges + Nr                               │
│  ├ Quick-Stats-Pill  │  ├ Titel (h2, 22px, weight 700)             │
│  ├ Typ-Tabs          │  ├ Stelle                                    │
│  └ Status-Filter     │  ├ Finanzieller Fluss (wenn Bescheid)        │
│                      │  └ Paperless-Link                            │
│  Antrag-Cards        │                                              │
│  (scrollbar)         │  Scrollbarer Body                            │
│  ├ MiniStepTrack     │  ├ WorkflowStepper                           │
│  ├ TypeBadge         │  ├ MetaSection (editierbar)                  │
│  ├ StatusBadge       │  ├ RechnungenSection                         │
│  └ Beträge           │  └ BescheideSection (mit Gauge)              │
│                      │                                              │
│  Footer (Anzahl)     │                                              │
└──────────────────────┴──────────────────────────────────────────────┘
```

---

## Komponenten

### Navigation
```
Höhe: 46px, Hintergrund: immer --nav (dunkel, beide Themes)
Logo: 26×26px, border-radius: 7px, SVG-Icon mit --primary Farbe
Wordmark: 14px, font-weight 700, rgba(255,255,255,0.92)
Aktiver Tab: font-weight 600, rgba(255,255,255,0.95), border-bottom: 2px solid --primary
Inaktiver Tab: rgba(255,255,255,0.38)
Datum: rgba(255,255,255,0.35), 11px
```

---

### Badges

```
Alle Badges: font-size 9-10px, font-weight 700, padding 2px 8px, border-radius 20px, letter-spacing 0.03em

TypeBadge — Beihilfe:
  bg: --blue-dim, color: --blue, border: rgba(74,136,245,.2)
  Label: "BH"

TypeBadge — PKV:
  bg: --teal-dim, color: --teal, border: rgba(0,196,176,.2)
  Label: "PKV"

StatusBadge Entwurf:        bg: --surface-hi,  color: --text-subtle, border: --border
StatusBadge Versendet:      bg: --blue-dim,    color: --blue,        border: rgba(74,136,245,.25)
StatusBadge In Bearbeitung: bg: --amber-dim,   color: --amber,       border: rgba(232,160,48,.25)
StatusBadge Beschieden:     bg: --green-dim,   color: --green,       border: rgba(78,200,122,.25)
StatusBadge Archiviert:     bg: --surface-hi,  color: --text-subtle, border: --border
Badge Widerspruch:          bg: --rose-dim,    color: --rose,        border: rgba(240,96,112,.25)
```

---

### Antrag-Listenkarte (AntragCard)

```
padding: 13px 16px
border-bottom: 1px solid --row-border
border-left: 3px solid transparent (default) | --primary (aktiv)
background: transparent → --row-hover (hover) → --row-active (aktiv)
transition: background .12s, border-color .12s

Aufbau (4 Zeilen):
  1. [TypeBadge] [StatusBadge] [ggf. Widerspruch-Badge]          [#nr rechts]
  2. Titel (13px, 600) links  |  Gesamtbetrag (13px, 700) rechts
     Stelle (10px, subtle)    |  BH-Betrag: grün/rose (10px, 600)
  3. MiniStepTrack links      |  Bescheid-Count (9px) + ggf. Löschen-Button

Löschen-Button:
  Nur sichtbar wenn status='Entwurf' UND Hover
  font-size 9px, bg: --rose-dim, color: --rose, border-radius: 10px
```

---

### MiniStepTrack (grafisches Element)

Horizontale Reihe von 4 Segmenten (Entwurf→Versendet→In Bearbeitung→Beschieden):

```
Vergangene Schritte:  width: 8px,  background: --green, opacity: 1
Aktiver Schritt:      width: 20px, background: --primary, opacity: 1
Zukünftige Schritte:  width: 8px,  background: --border-hi, opacity: 0.45

height: 3px, border-radius: 2px
transition: all .3s cubic-bezier(.34, 1.56, .64, 1)  ← Federfühlung!
gap: 3px
```

---

### Quick-Stats-Pill (Listenkopf)

Wird angezeigt wenn ≥1 aktive Anträge:
```
display: inline-flex, border-radius: 20px
background: --amber-dim, border: 1px solid rgba(232,160,48,.2)
padding: 3px 10px
Inhalt: Punkt (6×6px, rund, --amber) + "N offen" + "·" + Summe
font-size: 10px, font-weight: 700, color: --amber
```

---

### Typ-Tabs (Listenkopf)

Segmented Control für Alle / Beihilfe / PKV:
```
Wrapper: background --surface-alt, border-radius 8px, padding 3px
Tab aktiv:   background --surface, box-shadow 0 1px 4px rgba(0,0,0,.12), color --text
Tab inaktiv: background transparent, color --text-subtle
font-size: 11px, font-weight: 600, transition: all .15s
border-radius des aktiven Tab: 6px
```

---

### Neuanlage-Modal (CreateModal)

2-Schritt-Flow, zentriert im Viewport:
```
Hintergrund-Overlay: --overlay
Modal: background --surface, border --border, border-radius 16px, width 460px
box-shadow: 0 40px 100px rgba(0,0,0,.5)
animation: fade-in .22s ease

Step-Indikator im Header:
  2 Segmente (wie MiniStepTrack), width 8→20px je nach Status

SCHRITT 1 — Typ auswählen:
  2 große Karten nebeneinander (Beihilfe / PKV)
  Jede: 22px 18px padding, border-radius 12px, border 2px solid (Typ-Farbe)
  background: Typ-Farbe -dim
  Icon: 24px Emoji, Titel: 17px font-weight 800, Sub: 12px
  Hover: transform translateY(-2px), box-shadow mit Typ-Farbe

SCHRITT 2 — Details:
  "← zurück" Link + TypeBadge oben
  Felder: Stelle (select), Titel (text input, optional)
  Button-Reihe: [Abbrechen] [Antrag anlegen →]
  Bestätigen-Button disabled/opacity .45 wenn keine Stelle
```

---

### Workflow-Stepper (interaktiv, grafisches Element)

```
Wrapper: background --surface, border 1px solid --border, border-radius 14px, padding 20px 22px

Track:
  Hintergrundlinie: position absolute, top 15px, left/right 16px, height 2px, background --border
  Fortschrittslinie: selbe Position, width proportional zum aktuellen Step (%)
    background: linear-gradient(90deg, --green, --primary)
    transition: width .5s cubic-bezier(.4,0,.2,1)

Steps (flex, position relative über dem Track):
  Jeder Step: flexDirection column, alignItems center, gap 8px

  Vergangener Knoten (past):
    width/height 32px, border-radius 50%
    background --green, color #fff
    box-shadow: 0 2px 8px rgba(0,0,0,.15)
    Inhalt: "✓"

  Aktiver Knoten (current):
    background --primary, color #fff
    animation: pulse-glow 2.5s ease-in-out infinite
    @keyframes pulse-glow:
      0%,100% { box-shadow: 0 0 0 3px --primary-dim }
      50%      { box-shadow: 0 0 0 7px --primary-dim }

  Zukünftiger Knoten (future):
    background --surface-alt, color --text-subtle
    border: 2px dashed --border-hi
    cursor: pointer  ← klickbar!
    Klick → öffnet Bestätigungs-Panel

  Labels unter Knoten:
    font-size 9px, text-align center
    aktiv: font-weight 700, color --primary
    vergangen: font-weight 400, color --green
    zukünftig: font-weight 400, color --text-subtle

Bestätigungs-Panel (erscheint bei Klick auf zukünftigen Step):
  margin-top 16px
  background --bg, border 1px solid --primary, border-radius 10px, padding 14px 16px
  box-shadow: 0 0 0 3px --primary-dim
  animation: fade-in .18s ease
  Inhalt: [Dot 8×8px] "Status → [Schritt-Name]" [Datum-Input] [Abbrechen] [Bestätigen]
  
  Datum-Input wird angezeigt für: Versendet, In Bearbeitung, Beschieden
  Datum-Input: type="date", vorbelegt mit heute, width 146px
```

---

### Detail-Header (fester Bereich)

```
padding: 20px 28px 18px
background --surface, border-bottom 1px solid --border

Zeile 1: [TypeBadge] [StatusBadge] [ggf. Widerspruch] [#nr]
Zeile 2: Titel h2 (22px, 700, letter-spacing -.02em) | Betrag rechts (22px, 800)
Zeile 3: Stelle (12px, --text-muted)                  | Label "GESAMT" (9px, subtle)

Finanzieller Fluss-Block (nur wenn Bescheid vorhanden):
  background --surface-alt, border-radius 10px, padding 12px 14px
  
  Inline Flow:  [EINGEREICHT → ERSTATTET · ABGELEHNT] + Progress-Bar rechts

  Labels: 9px, font-weight 700, letter-spacing .06em, ALL CAPS
  Werte:  14px, font-weight 700, font-variant-numeric tabular-nums
  
  Progress-Bar:
    height 8px, border-radius 4px
    Track: --rose-dim (zeigt Gesamt-Breite als "abgelehnte" Basis)
    Fill: --green, width = approved/total × 100%
    transition: width .5s ease
  
  Erstattungsquote: 9px, --text-subtle, textAlign right
    Format: "XX % Erstattungsquote"

Paperless-Link:
  margin-top 10px, font-size 11px, color --primary, font-weight 500
  Präfix: "↗ "
```

---

### Meta-Section (editierbar)

```
background --surface, border 1px solid --border, border-radius 14px, padding 18px 20px

Header: Label "METADATEN" + Toggle-Button [Bearbeiten] / [Abbrechen] [Speichern]

Felder-Grid: 2 Spalten, gap 14px
Felder: Titel, Stelle, Notiz, Paperless-Link

View-Mode:
  Label: 9px, font-weight 700, --text-subtle, letter-spacing .06em, uppercase
  Wert:  13px, --text (oder --text-subtle + italic wenn leer)
  Paperless-Link: als klickbarer Link mit "↗" Präfix

Edit-Mode:
  input.field (Klasse): background --surface-alt, border 1px solid --border, border-radius 8px
  padding 8px 12px, font-size 13px, color --text
  :focus → border-color --primary, box-shadow 0 0 0 3px --primary-dim
```

---

### Rechnungen-Section

```
background --surface, border 1px solid --border, border-radius 14px, padding 18px 20px

Header: Label + "N Pos. · Gesamtbetrag" + [+ Hinzufügen] Button

Add-Dropdown (erscheint bei Klick):
  animation: fade-in .15s ease
  select.field + [OK] Button + [✕] Button
  Filterregel: nur Rechnungen die für diesen Typ noch nicht eingereicht (bhOffen/pkvOffen)

Rechnungszeilen (border-top --row-border, padding 9px 0):
  [R-XXXX (primary)] [Bescheid-Badge]     [Betrag rechts]
  [Person · Erbringer · Datum]            [Typ darunter, subtle]
  [✕-Button zum Entfernen, rose]

Bescheid-Badge vorhanden:
  bg --green-dim, color --green, border rgba(78,200,122,.2)
  Label: "Bescheid"

Bescheid-Badge fehlt:
  bg --surface-alt, color --text-subtle, border --border
  Label: "—"
```

---

### Bescheid-Card (mit Circular Gauge — grafisches Hauptelement)

```
border 1px solid --border, border-radius 14px, overflow hidden
opacity 0.55 wenn isOverridden (= nicht letzter Bescheid und mehrere vorhanden)

CARD-HEADER (immer sichtbar, klickbar → toggle):
  background --surface-alt, padding 16px 18px
  display flex, alignItems center, gap 16px

  ┌─────────────────────────────────────────────┐
  │  [Circular Gauge 68px]  │ [Info-Block]   ∧/∨│
  └─────────────────────────────────────────────┘

  Circular Gauge (SVG):
    Größe: 68×68px
    Zwei konzentrische Kreise (r = 68 × 0.37 ≈ 25px):
      Track:    stroke --surface-hi, strokeWidth 68×0.11 ≈ 7.5px
      Fill:     stroke = farbabhängig, strokeDasharray = pct × circumference
                transition: stroke-dasharray .7s cubic-bezier(.4,0,.2,1)
                strokeLinecap: round
    
    Farblogik der Fill-Stroke:
      pct >= 0.75 → --green
      pct >= 0.40 → --amber
      pct < 0.40  → --rose
    
    Prozent-Label zentriert:
      Zahl: size×0.2 ≈ 13px, font-weight 800, gleiche Farbe wie Stroke
      "%" : size×0.13 ≈ 9px, --text-subtle

  Info-Block (flex 1):
    Zeile 1: Typ-Name (13px, 700) + ggf. "überschrieben"-Badge + Datum rechts
    Zeile 2: Horizontaler Genehmigungsbalken
      height 6px, border-radius 3px, overflow hidden
      Track: --rose-dim (repräsentiert Abgelehntes)
      Fill:  --green, width = appPct × 100%, transition .6s cubic-bezier(.4,0,.2,1)
    Zeile 3: "↑ Erstattet" (--green, 11px, 700) + "↓ Abgelehnt" (--rose) + Aktenzeichen

CARD-BODY (sichtbar wenn open, animation: fade-in .18s ease):
  background --surface, padding 18px 18px 20px

  Positionen-Tabelle:
    Spalten: RECHNUNG | TATSÄCHL. KOSTEN | ANERKANNT | ABGELEHNT | ABLEHNUNGSGRUND
    Header:  9px, font-weight 700, letter-spacing .06em, --text-subtle, text-align right (außer erste)
    
    Zeilen:
      Rechnung-Spalte:    R-XXXX (11px, --primary, bold) + Rechnungsbetrag (--text-subtle)
      Tatsächl. Kosten:   Betrag (--text-muted) oder "—"
      Anerkannt:          Betrag (--green, font-weight 700) oder "0.00"
      Abgelehnt:          Betrag (--rose, font-weight 700) wenn >0.01, sonst "—"
      Ablehnungsgrund:    Text (--text-subtle, 11px) oder "—", max-width 140px
    
    Summe-Zeile:
      border-top 1px solid --border
      Anerkannt-Spalte: font-weight 800, color = Akzentfarbe (teal/amber je nach Typ)

  Summenprüfung:
    Vergleich: |sum(anerkannt) - gesamtbetrag| < 0.02 → OK / Abweichung
    
    OK:         background --green-dim, border rgba(78,200,122,.2)
                Kreis-Icon grün mit "✓", Text: "Positionssumme stimmt..."
    Abweichung: background --rose-dim,  border rgba(240,96,112,.2)
                Kreis-Icon rose mit "!", Text: "Abweichung X € — Bescheid: Y, Positionen: Z"
    
    Kreis-Icon: 20×20px, border-radius 50%, Icon-Farbe #fff, font-weight 700

  Notiz (wenn vorhanden):
    padding 10px 14px, background --surface-alt, border-radius 8px
    border-left: 3px solid --border-hi, font-size 12px, color --text-muted

  Footer:
    Label "BESCHEID-DOKUMENT" (9px, uppercase)
    Buttons: [⊙ Abfotografieren] [↑ PDF hochladen] — btn-ghost Stil
    Rechts: [Löschen] — plain button, color --rose
```

---

### Bescheid-Typ-Akzente

```
Erstbescheid:          Gauge/Bar-Farbe abhängig von Quote, Header-Punkt: --teal
Widerspruchsbescheid:  Gauge/Bar-Farbe abhängig von Quote, Header-Punkt: --amber
```

---

### Toast-Notification

```
position: fixed, bottom 24px, right 24px, z-index 200
background --surface, border 1px solid [Typ-Farbe]
border-radius 12px, padding 12px 18px
box-shadow: 0 8px 32px rgba(0,0,0,.35), 0 0 0 1px [Typ-Farbe]
animation: toast-in .25s ease
@keyframes toast-in: from { opacity:0; transform: translateY(12px) scale(.96) } to { opacity:1 }

Inhalt:
  [Kreis-Icon 28×28px, gerundet, Typ-Farbe Hintergrund, #fff Inhalt] + Text (13px, 500)

Typen:
  'success' → --green,   Icon: ✓
  'info'    → --primary, Icon: →
  'error'   → --rose,    Icon: !

Auto-Dismiss: nach 2.8 Sekunden
```

---

## Animationen

```css
@keyframes pulse-glow {
  0%, 100% { box-shadow: 0 0 0 3px var(--primary-dim); }
  50%       { box-shadow: 0 0 0 7px var(--primary-dim); }
}
@keyframes fade-in {
  from { opacity: 0; transform: translateY(6px); }
  to   { opacity: 1; transform: translateY(0); }
}
@keyframes slide-in {
  from { opacity: 0; transform: translateX(16px); }
  to   { opacity: 1; transform: translateX(0); }
}
@keyframes toast-in {
  from { opacity: 0; transform: translateY(12px) scale(.96); }
  to   { opacity: 1; transform: translateY(0) scale(1); }
}

Einsatz:
  Detail-Panel bei Auswahl eines Antrags: .anim-slide (slide-in)
  Modal:                                  fade-in
  Bestätigungs-Panel im Stepper:          fade-in
  Bescheid-Card-Body beim Öffnen:         fade-in
  Toast:                                  toast-in
  MiniStepTrack-Segmente:                 transition .3s cubic-bezier(.34,1.56,.64,1)
  Stepper Fortschrittslinie:              transition width .5s cubic-bezier(.4,0,.2,1)
  Gauge Fill:                             transition stroke-dasharray .7s cubic-bezier(.4,0,.2,1)
  Approval-Bar im Detail-Header:          transition width .5s ease
```

---

## Design Tokens — Chalk (Light)

```css
--bg: #EDEAE3;          --surface: #F8F5F0;     --surface-alt: #EDE9E2;
--surface-hi: #E4DED6;  --border: #D4CEC6;      --border-hi: #C2BAB2;
--text: #1C1914;        --text-muted: #6A6258;  --text-subtle: #A09888;
--nav: #1E1C18;         --nav-border: #2E2C28;
--primary: #2B5CE8;     --primary-dim: rgba(43,92,232,0.1);
--green: #1A9E58;       --green-dim: rgba(26,158,88,0.1);
--amber: #C87820;       --amber-dim: rgba(200,120,32,0.1);
--blue: #2B5CE8;        --blue-dim: rgba(43,92,232,0.1);
--rose: #D84060;        --rose-dim: rgba(216,64,96,0.1);
--teal: #189E8A;        --teal-dim: rgba(24,158,138,0.1);
--row-hover: rgba(0,0,0,0.03);
--row-active: rgba(43,92,232,0.07);
--row-border: rgba(0,0,0,0.07);
```

## Design Tokens — Carbon (Dark)

```css
--bg: #181818;          --surface: #212121;     --surface-alt: #292929;
--surface-hi: #323232;  --border: #3E3E3E;      --border-hi: #4E4E4E;
--text: #EBEBEB;        --text-muted: #888888;  --text-subtle: #555555;
--nav: #101010;         --nav-border: #282828;
--primary: #00C4B0;     --primary-dim: rgba(0,196,176,0.13);
--green: #4EC87A;       --green-dim: rgba(78,200,122,0.12);
--amber: #E8A030;       --amber-dim: rgba(232,160,48,0.12);
--blue: #4A88F5;        --blue-dim: rgba(74,136,245,0.12);
--rose: #F06070;        --rose-dim: rgba(240,96,112,0.12);
--teal: #00C4B0;        --teal-dim: rgba(0,196,176,0.12);
--row-hover: rgba(255,255,255,0.03);
--row-active: rgba(0,196,176,0.08);
--row-border: rgba(255,255,255,0.05);
```

## Theme-Aktivierung

```js
const saved = localStorage.getItem('pkv-theme');
const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
const theme = saved || (prefersDark ? 'carbon' : 'chalk');
document.documentElement.setAttribute('data-theme', theme);
```

---

## Typografie

```
Seitenüberschrift (h2):     22px, font-weight 700, letter-spacing -0.02em
Betrag im Header:           22px, font-weight 800, letter-spacing -0.025em
Section-Titel:              13px, font-weight 700
Bescheid-Typ:               13px, font-weight 700
Section-Labels (ALL CAPS):  9–10px, font-weight 700, letter-spacing 0.07–0.09em
Tabellen-Content:           12px
Tabellen-Header:            9px, font-weight 700, letter-spacing 0.06em
Beträge:                    font-variant-numeric: tabular-nums (überall)
Toast-Text:                 13px, font-weight 500
```

---

## Interaktionen & Verhalten

| Aktion | Verhalten |
|---|---|
| Klick auf Antragskarte | Auswahl + Detail-Panel zeigt neuen Antrag (slide-in Animation) |
| Klick auf zukünftigen Stepper-Step | Inline-Bestätigungs-Panel öffnet sich mit Datum-Input |
| Bestätigen im Stepper | Status wechselt, Toast erscheint, Panel schließt |
| Hover auf Entwurf-Karte | Löschen-Badge erscheint (on-hover, fade) |
| Klick Löschen | Antrag entfernt, kein Dialog nötig, Toast "Entwurf gelöscht" |
| Klick Bearbeiten (Meta) | Felder werden zu Inputs, Save/Cancel erscheint |
| Klick Speichern (Meta) | Werte aktualisiert, Toast "Gespeichert" |
| Klick + Hinzufügen (Rechnungen) | Dropdown öffnet sich (fade-in), zeigt nur berechtigte Rechnungen |
| Klick + Bescheid | Neuer Bescheid am Ende der Liste, vorbelegt mit heute + Rechnungs-Positionen |
| Klick Bescheid-Header | Card-Body toggle (open/close) |
| Klick ✕ (Rechnung) | Rechnung aus Antrag entfernt |

---

## Dateien in diesem Paket

```
design_handoff_pkv_themes/
├── ANTRAEGE_V3_INSTRUCTIONS.md   ← diese Datei
├── Anträge v3.html               ← lauffähiger Referenz-Prototyp
├── Anträge v2.html               ← Vorgängerversion (Referenz ohne Animationen)
├── Dashboard.html                ← Dashboard-Referenz
├── Rechnungen.html               ← Rechnungstabelle mit Detail-Panel
├── PKV Theme Proposal.html       ← Theme-Vergleich Chalk vs. Carbon
├── tweaks-panel.jsx              ← Hilfsdatei für Theme-Switcher im Prototyp
└── README.md                     ← Gesamt-Token-Dokumentation
```

**Öffne `Anträge v3.html` im Browser** und nutze den Tweaks-Button (oben rechts in der Toolbar) um zwischen Chalk und Carbon zu wechseln. Klicke Antrag `#0003` (Beschieden) für die vollständige Ansicht mit Gauge und Finanzfluss.
