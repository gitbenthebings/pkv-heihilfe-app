# Implementierungsanweisung: Belegverwaltung
**Claimbox · Belege — Übersicht + Slide-over mit Dokumentenviewer**

---

## Überblick

Die Belegseite ist ein **Dokumentenarchiv**. Links Filter, in der Mitte ein Karten-Grid aller Belege, und ein **Slide-over (rechts einfahrendes Panel)** zur vollständigen Bearbeitung eines Belegs. Aus dem Slide-over heraus lässt sich ein **aufklappbarer Dokumentenviewer** öffnen, der das Panel nach links schiebt und das Dokument rechts daneben anzeigt.

**Referenzdatei:** `Belege v4.html` — vollständiger, lauffähiger High-Fidelity-Prototyp. Im Browser öffnen, Theme über den Tweaks-Button umschalten (Chalk / Carbon).

**Wichtige Designentscheidung:** Der Slide-over ist KEIN Betrags-Editor mehr (kein Anerkannt/Abgelehnt-Schieberegler). Er bildet drei klare Funktionen ab: **Details bearbeiten · Verknüpfungen verwalten · Inhalt (OCR) ansehen**.

---

## Fidelity

**High-Fidelity.** Layout, Farben, Abstände, Interaktionen sind final. Die HTML-Datei ist Design-Referenz, kein Produktionscode — in der bestehenden App-Architektur neu implementieren.

---

## Datenmodell

```typescript
type BelegTyp = 'Rechnung' | 'Erstbescheid' | 'Widerspruchsbescheid' | 'Rezept' | 'Überweisung' | 'Sonstiges';

interface Beleg {
  id:        string;
  name:      string;        // Bezeichnung (ohne Dateiendung)
  typ:       BelegTyp;
  quelle:    string;        // Absender / Herkunft
  ext:       string;        // 'pdf' | 'jpg' | ...
  seiten:    number;
  ocr:       boolean;       // OCR abgeschlossen?
  ocrText:   string;        // erkannter Volltext
  datum:     string;        // ISO 'YYYY-MM-DD' (Belegdatum)
  uploaded:  string;        // ISO (Upload-/Importdatum)
  size:      string;        // '58 KB'
  notiz:     string;

  // Optionale fachliche Verknüpfungen (je nach Typ):
  rechnung?: RechnungRef;   // wenn der Beleg eine Rechnung IST
  bescheid?: BescheidRef;   // wenn der Beleg ein Bescheid IST
  antragId?: string | null; // direkt zugeordneter Antrag
}

interface RechnungRef {
  rId:      string;         // 'R-0018'
  betrag:   number;         // Brutto
  person:   string;         // Antragsteller (Stammdaten)
  erbringer:string;         // Leistungserbringer
  datum:    string;         // Behandlungsdatum (ISO)
  rgTyp:    string;         // 'Arzt' | 'Apotheke' | ...
  diagnose?:string;
  bezahlt?: boolean;
}

interface BescheidRef {
  bId:        string;       // 'B-002'
  antragId:   string;       // Bescheid antwortet auf genau einen Antrag
  typ:        'Erstbescheid' | 'Widerspruchsbescheid';
  datum:      string;
  aktenzeichen:string;
  gesamtbetrag:number;
  positionen: { rId:string; kosten:number }[];  // verknüpfte Rechnungen (1:n)
}
```

### Zentrale Geschäftsregeln

> **1 Bescheid : n Rechnungen** — ein Bescheid kann mehrere Rechnungsposten umfassen (`bescheid.positionen`).
> **1 Bescheid : 1 Antrag** — ein Bescheid antwortet auf genau einen Antrag (`bescheid.antragId`); Widersprüche erzeugen weitere Bescheide zum selben Antrag.
> **Rechnung → Bescheide** — zu einer Rechnung können mehrere Bescheide existieren (Erst- + Widerspruchsbescheid). Im Viewer werden sie über `positionen.rId` rückwärts ermittelt.

Für die Verknüpfungs-Anzeige existiert ein **Rechnungs-Stammdatensatz** (`RECHNUNGEN`, keyed nach `rId`) mit Betrag, Person, Erbringer, Datum — damit verknüpfte Rechnungen mit allen Infos dargestellt werden können.

---

## Seitenlayout

```
┌──────────────────────────────────────────────────────────────────────┐
│ NAV (immer dunkel, 48px) · aktiver Tab „Belege"                        │
├──────────┬─────────────────────────────────────────────────────────────┤
│ SIDEBAR  │  TOOLBAR: H1 „Belege" · Anzahl · [+ Beleg hochladen]        │
│ 236px    │           Suche ·············· Sortieren ▾                  │
│          ├─────────────────────────────────────────────────────────────┤
│ Typ      │  KARTEN-GRID (auto-fill, minmax(210px,1fr), gap 16)         │
│ Verknüpf.│   ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐                       │
│ Texterk. │   │ Karte│ │ Karte│ │ Karte│ │ Karte│  …                    │
│          │   └──────┘ └──────┘ └──────┘ └──────┘                       │
└──────────┴─────────────────────────────────────────────────────────────┘
```

### Sidebar (236px)
Drei Filtergruppen, jede mit Zähler-Badges rechts:
- **Typ:** Alle + alle `BelegTyp` (mit typfarbenem Punkt)
- **Verknüpfungen:** Alle · Verknüpft (grün) · Ohne Verknüpfung (amber)
- **Texterkennung:** Alle · OCR abgeschlossen (grün) · Ausstehend (amber)

### Toolbar
- H1 „Belege" + Subtext „Dokumentenarchiv · N Belege [· aktiver Typ]"
- Primär-Button „+ Beleg hochladen" (Pill, rechts)
- Suchfeld (Bezeichnung/Quelle/Notiz) + Sortieren (Neueste zuerst / Name A–Z)

### Beleg-Karte
- Faux-Dokumentvorschau (typfarbene Kopfzeile, Dateiendungs-Tag, Seitenzahl-Badge)
- Typ-Badge oben links
- Hover: Overlay „✎ Öffnen & bearbeiten" + Löschen-Button
- Footer: Person-Avatar(e) · Betrag (falls Rechnung) · Verknüpfungs-Badge (`⛓ N` grün bzw. „frei" amber) · OCR-Status

### Drag & Drop
Vollflächige Dropzone-Overlay beim Datei-Ziehen („Dateien hier ablegen · automatische OCR-Erkennung").

---

## Slide-over (Detail-Panel) — der Kern

Rechts einfahrendes Panel, **Breite 600px** (max 96vw), Overlay-Backdrop dahinter (Klick = schließen).

### Kopf (Header)
```
[Mini-Vorschau 46×58]  [Typ-Badge] [Belegdatum]          [⤢ Vorschau] [×]
                       Bezeichnung (max 2 Zeilen, 15px/700)
                       Größe · Uploaddatum
─────────────────────────────────────────────────────────────────────────
[ Details ]  [ Verknüpfungen N ]  [ Inhalt OCR ]    ← Tab-Leiste
```
- **„⤢ Vorschau"** öffnet/schließt den Dokumentenviewer (siehe unten). Aktiver Zustand: primärfarbig hervorgehoben.
- Tab „Verknüpfungen" trägt einen Zähler-Badge (Summe aller Verknüpfungen).
- Tab „Inhalt" trägt ein kleines „OCR"-Tag (grün wenn fertig).

### Tab 1 — Details
```
Grid 2-spaltig:
  TYP (Select)            DATUM (date)
  BEZEICHNUNG (Input, voll)
  NOTIZ (Textarea, voll)
[ Speichern ] (primär)
──────────────── (Trennlinie) ────────────────
DATEI
  Dateiname (voll, umbruchfähig: name.ext)   Größe
  Hochgeladen                                Texterkennung (✓ Abgeschlossen / ○ Ausstehend)
[ Beleg löschen ] (rose, outline)
```

### Tab 2 — Verknüpfungen (Liste verwalten, KEINE Betragsbearbeitung)
Oben eine **Summary-Zeile**: `⛓ N · Verknüpfungen mit diesem Beleg`.

Danach **typabhängige Sektionen**, jede mit Label + Zähler:

**Bei einem Bescheid:**
- **RECHNUNGEN** (Hint: „1 Bescheid : n Rechnungen") — Liste der verknüpften Rechnungen aus `positionen`. Jede Zeile = Karte:
  ```
  │ [accent] Betrag (15px/700)              Datum (rechts)   [ × ]
  │          [Avatar] Erbringer · Person
  ```
  × entfernt die Verknüpfung. Darunter Button **„+ Verknüpfung hinzufügen"** → klappt einen Picker auf (Liste wählbarer Rechnungen mit Avatar/Betrag/Erbringer, Klick = verknüpfen).
- **ANTRAG** (Hint: „beantwortet durch Bescheid") — eine Antrags-Karte (Nr., Titel, Status-Pill mit Statusfarbe, BH/PKV-Badge) mit × zum Lösen, bzw. „Antrag zuordnen"-Picker wenn keiner gesetzt.

**Bei einer Rechnung:**
- **BESCHEIDE** — read-only Liste der Bescheide, die diese Rechnung referenzieren (Erst/Widerspruch farblich, Aktenzeichen, Gesamtbetrag, Datum). Klick öffnet den Bescheid.
- **ANTRAG** — wie oben.

**LinkRow-Komponente (wiederverwendbar):** farbiger Accent-Streifen (3px) links nach Typ, klickbarer Inhaltsbereich (öffnet Ziel), optionaler ×-Entfernen-Button rechts (border-left, Hover rose).

Statusfarben Antrag: Entwurf=subtle · Versendet=blau · In Bearbeitung=amber · Beschieden=grün.

### Tab 3 — Inhalt (OCR)
```
┌ grüne Statusleiste ───────────────────────────────────────────────┐
│ ✓ Abgeschlossen · 3.024 Zeichen                  [ ↻ OCR wiederholen ]│
└────────────────────────────────────────────────────────────────────┘
[ ⌕ Im erkannten Text suchen…        N Treffer ]   [ ⧉ Kopieren ]
┌ Monospace-Textbox (scrollbar) ─────────────────────────────────────┐
│ <erkannter Volltext, Suchtreffer gelb hervorgehoben>               │
└────────────────────────────────────────────────────────────────────┘
Automatisch erkannt am <Datum> · Volltext durchsuchbar
```
- „↻ OCR wiederholen" stößt die Texterkennung neu an.
- „⧉ Kopieren" kopiert den Volltext in die Zwischenablage.
- Live-Suche hebt Treffer im Text hervor und zählt sie.
- Ohne OCR: Leerzustand mit Button „Texterkennung starten".

---

## Dokumentenviewer (aufklappbar) — NEU

Wird über **„⤢ Vorschau"** im Slide-over-Kopf getoggelt.

### Verhalten
- Beim Öffnen **schiebt sich der Slide-over nach links** (sein `right`-Offset animiert von 0 auf die Viewer-Breite) und der **Viewer fährt am rechten Rand ein** (slide-in von rechts).
- Der Viewer ist am rechten Bildschirmrand verankert (hinter dem Panel, z-index 1; Panel z-index 2).
- Schließen über das **×** im Viewer-Kopf oder erneut **„⤢ Vorschau"**.

### Aufbau (Breite ~470px, max 46vw)
```
┌ Kopf (50px) ───────────────────────────────────────────────┐
│ ● dateiname.pdf                                       [ × ] │
│   58 KB · 3 Seiten                                          │
├ Papierfläche (scrollbar, zentriert) ───────────────────────┤
│        ┌──────────────────────────┐                        │
│        │  [typfarbene Kopfbalken]  │  ← weißes Blatt        │
│        │  Dokumenttext (Serif)…    │     (Inhalt = ocrText) │
│        │  …                        │                        │
│        └──────────────────────────┘                        │
├ Werkzeugleiste (46px) ──────────────────────────────────────┤
│ [ ‹ ]  Seite 1/3  [ › ]            [ − ]  100%  [ + ]       │
└─────────────────────────────────────────────────────────────┘
```
- **Papier-Seite:** weißes Blatt (fix hell, themeunabhängig) mit Schlagschatten; typfarbene Titelbalken oben; darunter der erkannte Text in Serifenschrift (erste Zeile als Titel fett). Ohne OCR: graue Platzhalterzeilen.
- **Seiten-Navigation:** ‹ / › mit „Seite x/N", Buttons am Rand deaktiviert.
- **Zoom:** − / + zwischen 60 % und 180 % (umgesetzt via CSS `zoom` auf die Seite).

### Implementierungshinweis (wichtig für die echte App)
Im Prototyp ist die Seite eine stilisierte Nachbildung des OCR-Texts. **In der echten App hier den tatsächlichen PDF/Bild-Render einsetzen** (z. B. `pdf.js`-Canvas oder `<img>` pro Seite). Kopf-, Seiten- und Zoom-Steuerung bleiben wie spezifiziert; Seitenwechsel rendert die jeweilige Seite, Zoom skaliert den Render.

### Layout-/Responsive-Hinweis
Panel (600) + Viewer (470) brauchen ≈ 1070px Breite, um nebeneinander vollständig zu passen. Auf schmaleren Fenstern:
- Viewer-Breite über `max-width: 46vw` automatisch verkleinern (bereits so).
- Optional bei < ~1000px: Viewer als Vollbild-Overlay statt nebeneinander.

---

## Theme-Tokens (Chalk hell / Carbon dunkel)

Identisch zu den anderen Seiten der App. Aktivierung über `data-theme`-Attribut auf `<html>`:

```js
const saved = localStorage.getItem('pkv-theme');
const prefersDark = matchMedia('(prefers-color-scheme: dark)').matches;
document.documentElement.setAttribute('data-theme', saved || (prefersDark ? 'carbon' : 'chalk'));
```

Verwendete CSS-Variablen u. a.: `--bg --surface --surface-alt --surface-hi --border --border-hi --text --text-muted --text-subtle --nav --primary(-dim/-hover) --green/-dim --amber/-dim --blue/-dim --teal/-dim --rose/-dim --purple/-dim --paper --overlay --row-hover/-active/-border`.

Typfarben-Zuordnung (`TYPE_TONE`): Rechnung=amber · Erstbescheid=teal · Widerspruchsbescheid=rose · Rezept=green · Überweisung=blue · Sonstiges=purple.

---

## Interaktionen — Zusammenfassung

| Element | Verhalten |
|---|---|
| Karte klicken / „Öffnen & bearbeiten" | Slide-over öffnet sich mit diesem Beleg |
| Hover Karte → 🗑 | Beleg löschen (mit Toast) |
| „⤢ Vorschau" | Dokumentenviewer auf/zu — Panel rückt nach links |
| Tab wechseln | Details / Verknüpfungen / Inhalt |
| „+ Verknüpfung hinzufügen" | Picker aufklappen, Eintrag wählen → verknüpfen |
| × an LinkRow | Verknüpfung entfernen |
| LinkRow-Inhalt klicken | Ziel öffnen (Rechnung/Antrag/Bescheid) |
| „↻ OCR wiederholen" | Texterkennung neu starten |
| „⧉ Kopieren" | OCR-Volltext in Zwischenablage |
| Suche im Inhalt | Treffer hervorheben + zählen |
| Datei auf Seite ziehen | Dropzone → Upload + OCR |

Alle Schreibaktionen geben einen **Toast** unten rechts aus (success/info/error).

---

## Komponentenbaum (Orientierung)

```
App
├─ Nav
├─ Sidebar (FilterGroup / FilterRow)
├─ Toolbar (Suche, Sortierung, Upload)
├─ Grid → BelegCard (DocThumb, TypeBadge, PersonChips)
├─ BelegDrawer (wenn ein Beleg gewählt)
│   ├─ Drawer-Shell  (Panel + optionaler DocViewer rechts daneben)
│   │   ├─ DocViewer (DocPage, Seiten-/Zoom-Toolbar)
│   │   └─ Panel
│   │       ├─ Header (Mini-Vorschau, Titel, „⤢ Vorschau", ×, Tabs)
│   │       └─ Body
│   │           ├─ DetailsTab
│   │           ├─ VerknuepfungenTab (LinkSection, LinkRow, AddLink, AntragRow)
│   │           └─ InhaltTab (Status, Suche, Kopieren, Volltext)
└─ Toast / Dropzone-Overlay
```

---

## Hinweise an Claude Code

1. **Slide-over + Viewer als eine Einheit:** Der Viewer ist am rechten Rand fixiert; das Panel wird über einen animierten `right`-Offset (= Viewer-Breite) nach links verschoben. Beide Endzustände prop-/state-gesteuert (kein Verlass auf Keyframe-Animationen für die Ruheposition).
2. **Verknüpfungen = Beziehungen verwalten**, nicht Beträge. Anerkannt/Abgelehnt-Beträge werden NICHT hier, sondern in der Antrags-/Bescheid-Funktionalität gepflegt.
3. **Echter Dokument-Render** im Viewer statt der stilisierten Papier-Nachbildung (pdf.js o. Ä.); Seiten-/Zoom-Controls beibehalten.
4. **Reaktiv:** Verknüpfungs-Zähler, OCR-Status und Listen sollen sich live aus den Daten ableiten.
5. **Read-only-Querverweise:** „Antrag/Bescheid öffnen" navigiert in die jeweilige Funktionalität.
6. **Barrierefreiheit:** Tab-Reihenfolge im Slide-over, ESC schließt Viewer dann Panel, Fokus-Falle im offenen Panel.

---

## Dateien

```
Belege v4.html   ← maßgebliche Referenz (dieser Stand)
Belege v3.html   ← Vorgänger (Sicherung)
```

Öffne `Belege v4.html`, öffne einen **Bescheid** (zeigt mehrere verknüpfte Rechnungen) und klicke im Kopf auf **„⤢ Vorschau"**, um Slide-over + Dokumentenviewer im Zusammenspiel zu sehen. Theme über Tweaks (Chalk/Carbon) umschaltbar.
