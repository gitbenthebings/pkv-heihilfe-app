# Implementierungsanweisung: Dashboard
**PKV-Abrechnung · Hauptansicht**

---

## Überblick

Das Dashboard ist die zentrale Übersicht der App. Es zeigt auf einen Blick, welche Beträge **voraussichtlich** von Beihilfe und PKV zu erwarten sind, wie der Workflow aktuell aussieht, welche Bescheide zuletzt eingegangen sind und welche Anträge offen sind.

**Wichtiges Designprinzip:** Read-only. Keine Bearbeitung von Rechnungen oder Anträgen direkt im Dashboard — alle Aktionen führen zu den entsprechenden Listen-Ansichten (Rechnungen, Anträge).

**Referenzdatei:** `Dashboard.html` — High-Fidelity-Prototyp. Im Browser öffnen, Tweaks-Button zum Theme-Wechsel.

---

## Fidelity

**High-Fidelity.** Pixel-genaue Umsetzung. Layout, Farben, Abstände und Anzeigelogik sind final. Die HTML-Datei ist eine Design-Referenz — kein Produktionscode. In der bestehenden App-Architektur neu implementieren.

---

## Layout-Struktur

Drei Hauptbereiche, alle auf maximal **1320px Breite** zentriert, **Padding 16px 20px**:

```
┌────────────────────────────────────────────────────────────────────────┐
│ NAV (immer dunkel, 48px)                                               │
├────────────────────────────────────────────────────────────────────────┤
│ HERO  →  [Begrüßung links] ............. [3 kompakte Stat-Boxes rechts]│
├────────────────────────────────────────────────────────────────────────┤
│ ┌──────── BEIHILFE-PIPELINE ────────┐  ┌────── PKV-PIPELINE ──────────┐│
│ │ [Header] · Pill "OFFEN: XX €"     │  │ [Header] · Pill "OFFEN: XX €"││
│ │ Einreichbar→Eingereicht→Erstat→Abg│  │ Einreichbar→...→Abgelehnt    ││
│ └───────────────────────────────────┘  └──────────────────────────────┘│
├────────────────────────────────────────────────────────────────────────┤
│ ┌─── LETZTE BESCHEIDE ───┐ ┌─ OFFENE ANTRÄGE ─┐ ┌── BEITRAGSRÜCK. ──┐  │
│ │ Bar-Chart, 6 Bescheide │ │ Liste, 4 Anträge │ │ 3 Personen-Cards  │  │
│ │ flex: 1.5              │ │ flex: 1          │ │ flex: 1           │  │
│ └────────────────────────┘ └──────────────────┘ └───────────────────┘  │
└────────────────────────────────────────────────────────────────────────┘
```

Gap zwischen Sektionen: **12px**. Gesamthöhe so optimiert, dass es **in ~900px Viewport ohne Scrollen** passt.

---

## Datenmodell

```typescript
// Beihilfe und PKV teilen sich die gleiche Pipeline-Struktur
interface PipelineData {
  einreichbar: {
    rechnungBrutto:  number;   // Summe Rechnungsbeträge (informativ)
    voraussichtlich: number;   // erwartete Erstattung = brutto × Satz (Hauptzahl!)
    anzahl:          number;   // Anzahl Rechnungen
  };
  eingereicht: {
    rechnungBrutto:  number;
    voraussichtlich: number;
    anzahl:          number;
  };
  erstattet: {
    tatsaechlich: number;      // tatsächliche Erstattung aus Bescheiden
    anzahl:       number;
  };
  abgelehnt: {
    tatsaechlich: number;      // tatsächlich abgelehnter Betrag
    anzahl:       number;
  };
}

interface Bescheid {
  kurz:        string;         // 'B-008'
  datum:       string;         // 'DD.MM.'
  stelle:      string;         // 'BVA' | 'HUK' | ...
  typ:         'Beihilfe' | 'PKV';
  eingereicht: number;         // urspr. eingereichter Betrag
  erstattet:   number;
  abgelehnt:   number;
  ws:          boolean;        // ist ein Widerspruchsbescheid
  overridden?: boolean;        // wurde von späterem Bescheid überschrieben → opacity 0.4
}

interface OffenerAntrag {
  nr:      string;             // '#0001'
  titel:   string | null;
  typ:     'Beihilfe' | 'PKV';
  status:  'Entwurf' | 'Versendet' | 'In Bearbeitung' | 'Beschieden';
  anzahl:  number;             // Anzahl Rechnungen
  betrag:  number;
}

interface BeitragsRueck {
  name:        string;
  offen:       number;         // noch nicht eingereicht
  eingereicht: number;         // bei PKV eingereicht
  schwelle:    number;         // jährliche Schwelle, 0 = bereits ausgeschöpft
  erstattet:   number;         // historisch erstattet
}
```

**Wichtige Geschäftsregel:**
> Der „voraussichtliche" Betrag ist immer der **erwartete Erstattungsbetrag** (z.B. 50 % vom Brutto bei Standard-Beihilfe, 70 % bei Kindern). Der Brutto-Rechnungsbetrag erscheint nur als sekundäre Info („v. 526 € brutto").
>
> Diese Berechnung muss pro Rechnung/Person konfigurierbar sein (jeder Antragsteller hat einen Beihilfesatz).

---

## Komponenten — Detailspezifikation

### Hero (eine Zeile)

```
display: flex, alignItems: center, justifyContent: space-between
gap: 18px, flexWrap: wrap, marginBottom: 12px

LINKS (Greeting-Block):
  Eyebrow:  "Dashboard · 2026"
    fontSize 10px, font-weight 600, --text-subtle, letter-spacing 0.08em, uppercase
  Headline: "Guten Morgen, [Name]."
    fontSize 19px, font-weight 700, --text, letter-spacing -0.02em

RECHTS (3 inline Stat-Boxen, alle gleicher Stil):
  Wrapper: background --surface, border 1px solid --border, border-radius 10px,
           display: flex, overflow: hidden
  
  Pro Box: padding 9px 16px, border-right 1px solid --border (außer letzte)
    Label (9px, font-weight 700, --text-subtle, letter-spacing 0.06em):
      "VORAUSSICHTL. BEIHILFE"  → color: --blue
      "VORAUSSICHTL. PKV"        → color: --teal
      "ERSTATTET 2026  ↑"        → color: --green, Box-Background: --surface-alt
    Value (17px, font-weight 700, letter-spacing -0.02em, tabular-nums)
      Farbe entspricht dem Label-Akzent
```

---

### Pipeline-Card (2× nebeneinander, einmal Beihilfe, einmal PKV)

```
Card: background --surface, border 1px solid --border, border-radius 12px

HEADER (padding 9px 14px 7px, border-bottom 1px solid --border):
  Display: flex, alignItems center, justifyContent space-between
  
  LINKS:
    Titel:    10px, font-weight 700, --text-subtle, letter-spacing 0.09em, uppercase
              "BEIHILFE-PIPELINE · 2026"  oder  "PKV-PIPELINE · 2026"
    Subtitle: 10px, --text-subtle, marginTop 1px
              Beihilfe: "50 % Standard · 70 % Kinder"
              PKV:      "gem. Tarifsatz"
  
  RECHTS — Pill "OFFEN":
    display: inline-flex, alignItems center, gap 5px
    background: --blue-dim (Beihilfe) / --teal-dim (PKV)
    color:      --blue / --teal
    borderRadius 14px, padding 2px 9px
    Label "OFFEN" (9px, font-weight 700, letter-spacing 0.04em)
    Value: einreichbar.voraussichtlich + eingereicht.voraussichtlich
           (12px, font-weight 800, tabular-nums)

BODY (padding 2px 4px, display flex):
  4 PipelineStage Komponenten + 3 Chevron-Separatoren dazwischen
```

---

### PipelineStage

```
Display: flex 1, padding 9px 12px, flexDirection column, gap 3px

Zeile 1 — Label + Count Badge:
  Label (9px, font-weight 700, --text-subtle, letter-spacing 0.06em, uppercase):
    "EINREICHBAR" | "EINGEREICHT" | "ERSTATTET" | "ABGELEHNT"
  Count-Badge (rechts):
    background --[tone]-dim, color --[tone]
    fontSize 9px, font-weight 700, padding 1px 6px, border-radius 10px, tabular-nums

Zeile 2 — Hauptzahl:
  15px, font-weight 700, --[tone], letter-spacing -0.01em, tabular-nums
  fmtS(value): "245 €", "1.326 €" (gerundet, kein Nachkomma)

Zeile 3 — Subtext:
  9px, --text-subtle, tabular-nums
  Für Einreichbar/Eingereicht: "v. 526 € brutto"
  Für Erstattet/Abgelehnt:     "tatsächlich"

Tone-Mapping (entspricht --green/--amber/--blue/--rose CSS-Variablen):
  Einreichbar → amber
  Eingereicht → blue
  Erstattet   → green
  Abgelehnt   → rose
```

**Chevron-Separator** zwischen Stages (außer nach letzter):
```
display: flex, alignItems center, padding: 0 3px
SVG (12×12px), color --border-hi
Path: "M5 3 L10 8 L5 13", strokeWidth 1.5, strokeLinecap round
```

---

### Bescheide-Bar-Chart (Letzte Bescheide)

```
Card: --surface, border --border, border-radius 12px, padding 14px 16px

Header (SectionLabel):
  "LETZTE BESCHEIDE" Label + "Alle →" Action-Link (--primary)

Body — Zeilen-Grid:
  display: flex, flexDirection column, gap 5px
  
  Pro Bescheid: display grid, gridTemplateColumns "50px 1fr 76px", gap 8px
    opacity: 0.4 wenn overridden, sonst 1

  Spalte 1 — Datum + Stelle (50px):
    Datum: 10px, --text, font-weight 600, tabular-nums
    Stelle: 8px, font-weight 700
      Beihilfe → --blue, PKV → --teal

  Spalte 2 — Stacked Bar (flex 1, height 14px):
    Bar-Wrapper: width = eingereicht/maxBetrag × 100%
                 background --surface-alt, borderRadius 3px
    Grün-Segment: width = erstattet/eingereicht × 100%, background --green
    Rose-Segment: width = rest × 100%, background --rose, opacity 0.85
    transition: width .4s ease

    Wenn ws=true (Widerspruch):
      WSP-Badge daneben (position absolute, left = "calc(width% + 5px)"):
        7px, font-weight 700, padding 1px 4px, borderRadius 6px
        background --amber-dim, color --amber, border rgba(232,160,48,.25)

  Spalte 3 — Werte rechts (76px, textAlign right):
    Oben: erstattet, 11px, font-weight 700, --green, tabular-nums
    Unten: "v. " + eingereicht, 8px, --text-subtle, tabular-nums

Footer — Legende (margin-top 8px, padding-top 7px, border-top 1px solid --row-border):
  display: flex, gap 10px, fontSize 9px, color --text-muted
  ▢ erstattet (--green)   ▢ abgelehnt (--rose)   N Bescheide (margin-left auto)
```

---

### Offene Anträge

```
Card: padding 14px 16px
Header: "OFFENE ANTRÄGE" + "Alle →"

Body — gestapelte kompakte Karten:
  display: flex, flexDirection column, gap 5px
  
  Pro Antrag:
    display flex, alignItems center, gap 8px, padding 6px 8px
    borderRadius 6px, background --surface-alt, cursor pointer
    
    LINKS — Status-Streifen:
      width 4px, height 28px, borderRadius 2px
      background = --[statusTone]
        Entwurf        → --text-subtle
        Versendet      → --blue
        In Bearbeitung → --amber
        Beschieden     → --green
    
    MITTE — Antrag-Info (flex 1):
      Zeile 1: Nr (9px, --text-subtle, font-weight 600) + Typ-Badge
        Typ-Badge: fontSize 8px, font-weight 700, padding 1px 5px, borderRadius 6px
          Beihilfe: bg --blue-dim, color --blue, Label "BH"
          PKV:      bg --teal-dim, color --teal, Label "PKV"
      Zeile 2: Titel (11px, --text, font-weight 500, ellipsis)
        Wenn null: "Kein Titel" in --text-subtle, italic
    
    RECHTS — Status + Betrag (textAlign right):
      Status: 8px, --[statusTone], font-weight 700, letter-spacing 0.04em, uppercase
      Betrag: 11px, --text, font-weight 700, tabular-nums (gerundet)
```

---

### PKV-Beitragsrückerstattung

```
Card: padding 14px 16px
Header: "PKV-BEITRAGSRÜCKERSTATTUNG" + "Details →"

Body — eine Karte pro Person, gap 8px:

Pro Karte:
  padding 2px 0
  
  Zeile 1 — Name + Status:
    Name (11px, font-weight 600, --text)
    Status rechts (9px, --text-subtle):
      Wenn erstattet > 0: "{betrag} erst." in --green
      Sonst wenn schwelle > 0: "Schw. {betrag}"
      Sonst: "keine Schw."
  
  Zeile 2 — Stacked Progress Bar (nur wenn Schwelle > 0):
    height 5px, borderRadius 3px, background --surface-alt
    Blau-Segment (--blue): width = eingereicht/schwelle × 100%
    Amber-Segment (--amber, opacity 0.7): width = offen/schwelle × 100%
                                            left = eingereicht/schwelle × 100%
  
  Falls Schwelle = 0 und schon Erstattung erfolgt:
    "ausgeschöpft" in --text-subtle italic, 10px
```

---

## Theme-Tokens

**Identisch zu allen anderen Seiten** — Chalk (Light) und Carbon (Dark). Siehe `ANTRAEGE_V3_INSTRUCTIONS.md` für vollständige Tokens.

```css
/* Theme-Aktivierung */
const saved = localStorage.getItem('pkv-theme');
const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
document.documentElement.setAttribute('data-theme', saved || (prefersDark ? 'carbon' : 'chalk'));
```

---

## Navigation

Identische Nav-Leiste wie auf allen Seiten:
```
Höhe: 48px, background: --nav (immer dunkel)
Aktiver Tab: "Dashboard" → border-bottom 2px solid --primary
```

---

## Responsive / Größenbegrenzung

- **Container max-width: 1320px**, zentriert
- **Padding: 16px 20px 24px** (kompakt)
- **Gaps zwischen Hauptsektionen: 12px**
- Layout ist für **Desktop optimiert** (≥ 1280px Breite)
- Bei sehr schmalen Viewports darf der Hero die rechten Stat-Boxen umbrechen (flexWrap auf Hero-Container)

---

## Typografie-Skala (kompakt)

```
H1 (Greeting):        19px, font-weight 700, letter-spacing -0.02em
Section-Labels:       10px, font-weight 700, --text-subtle, letter-spacing 0.09em
Card-Sub-Labels:      9–10px, font-weight 700, letter-spacing 0.06–0.08em
Hauptbeträge:         15–17px, font-weight 700, tabular-nums
Sekundärbeträge:      10–11px, font-weight 700, tabular-nums
Untertexte:           9–10px, --text-subtle
Beträge generell:     font-variant-numeric: tabular-nums (überall)
```

---

## Helper-Funktionen

```js
// Volle Formatierung mit 2 Nachkommastellen
fmt(123.45)  → "123,45  €"

// Kompakte gerundete Darstellung
fmtS(123.45) → "123 €"
fmtS(1326.18) → "1.326 €"

// Beide nutzen 'de-DE' Locale
```

---

## Interaktionen

| Element | Verhalten |
|---|---|
| Klick Nav-Tab "Dashboard" | Bleibt auf Dashboard (kein Effekt) |
| Klick Nav-Tab "Rechnungen/Anträge" | Navigiert zu jeweiliger Seite |
| Klick "Alle →" Links | Navigiert zu vollständiger Liste der Sektion |
| Klick Offene-Antrag-Karte | Navigiert zu Anträge-Seite mit dem Antrag selektiert |
| Klick Bescheid in Chart | (optional) Navigiert zum zugehörigen Antrag |
| Hover Offene-Antrag-Karte | Kein spezieller State |
| Theme-Toggle | Wechselt via `data-theme` Attribut |

**Keine Editier-Funktionen direkt im Dashboard** — alle Bearbeitung erfolgt in den Listen.

---

## Daten-Beispiele aus dem Prototyp

```js
const BEIHILFE_PIPELINE = {
  einreichbar: { rechnungBrutto: 526.04,  voraussichtlich: 280.51, anzahl: 2 },
  eingereicht: { rechnungBrutto: 2421.92, voraussichtlich: 1326.18, anzahl: 7 },
  erstattet:   { tatsaechlich: 2448.27, anzahl: 9 },
  abgelehnt:   { tatsaechlich:  387.21, anzahl: 3 },
};

const PKV_PIPELINE = {
  einreichbar: { rechnungBrutto: 526.04, voraussichtlich: 245.53, anzahl: 2 },
  eingereicht: { rechnungBrutto:  12.87, voraussichtlich:   5.79, anzahl: 1 },
  erstattet:   { tatsaechlich: 524.40, anzahl: 4 },
  abgelehnt:   { tatsaechlich:  38.20, anzahl: 1 },
};

// Beispiel-Beihilfesatz-Berechnung:
// rechnungBrutto = 526.04
// Person hat 50 % Beihilfesatz
// voraussichtlich = 526.04 × 0.50 = 263.02
// (im Beispiel oben sind die Werte gemischt aus Standard + Kinder)
```

---

## Hinweise an Claude Code

1. **Berechnungslogik:** Der `voraussichtlich`-Betrag wird **pro Rechnung** aus dem zugeordneten Beihilfesatz bzw. PKV-Tarif berechnet. Bei Beihilfe-Standardsatz 50 %, bei Kindern 70 %. Diese Sätze gehören in die Stammdaten der Personen.

2. **Trennung Beihilfe/PKV:** Die zwei Pipelines existieren parallel — eine Rechnung kann gleichzeitig in beide einreichbar sein (z.B. zu 50 % Beihilfe + 50 % PKV).

3. **Read-only:** Das Dashboard zeigt nur Daten. Alle Bearbeitungen führen weg von hier zu Rechnungen oder Anträge.

4. **Bescheide-Chart:** Die maximale Balkenbreite richtet sich nach `eingereicht`-Wert des größten Bescheids. Skalierung erfolgt proportional.

5. **Auto-Aktualisierung:** Werte sind live aus Anträgen, Rechnungen und Bescheiden berechnet — sollten reaktiv auf Änderungen reagieren.

---

## Dateien

```
design_handoff_pkv_themes/
├── DASHBOARD_INSTRUCTIONS.md     ← diese Datei
├── Dashboard.html                ← lauffähiger Prototyp
├── ANTRAEGE_V3_INSTRUCTIONS.md   ← Anträge-Seite
├── Anträge v3.html
├── Rechnungen.html               ← Rechnungs-Liste
├── README.md                     ← Theme-Token-Dokumentation
└── tweaks-panel.jsx              ← Helper für Theme-Switcher
```

Öffne `Dashboard.html` und schalte via Tweaks-Button zwischen **Chalk** (hell) und **Carbon** (dunkel) um.
