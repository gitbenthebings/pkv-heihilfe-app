# Handoff: PKV-Abrechnung — Theme-System (Chalk + Carbon)

## Übersicht

Dieses Paket beschreibt das neue visuelle Design für die PKV-Abrechnung App.  
Es enthält zwei Themes: **Chalk** (Light) und **Carbon** (Dark), die als konsistentes Paar implementiert werden sollen.

Die beiliegenden HTML-Dateien sind **High-Fidelity Design-Referenzen** — keine produktionsreifen Komponenten. Die Aufgabe ist es, diese Designs in der bestehenden App-Codebase (oder dem passenden Framework) zu **re-implementieren**, unter Verwendung vorhandener Patterns, Libraries und Komponenten-Struktur.

---

## Fidelity

**High-Fidelity.** Farben, Typografie, Abstände, Hover-States und Interaktionen sind final und sollen pixel-genau übernommen werden.

---

## Design-Referenzdateien

| Datei | Inhalt |
|---|---|
| `PKV Theme Proposal.html` | Dashboard — Chalk (links) vs. Carbon (rechts) im Vergleich |
| `Rechnungen.html` | Rechnungstabelle mit Bearbeitungs-Panel — alle 3 Themes umschaltbar via Tweaks |

---

## Design Tokens

### Chalk (Light Theme)

```css
[data-theme="chalk"] {
  /* Hintergründe */
  --bg:          #EDEAE3;   /* Page background — warmes Cremegrau */
  --surface:     #F8F5F0;   /* Karten, Tabellen, Panels */
  --surface-alt: #EDE9E2;   /* Alternativer Surface (z.B. Table-Header) */
  --surface-hi:  #E4DED6;   /* Elevated Surface (z.B. Hover-State Panels) */

  /* Borders */
  --border:      #D4CEC6;   /* Standard-Border */
  --border-hi:   #C2BAB2;   /* Stärkerer Border */

  /* Typografie */
  --text:        #1C1914;   /* Primärtext */
  --text-muted:  #6A6258;   /* Sekundärtext, Labels */
  --text-subtle: #A09888;   /* Placeholder, deaktiviert */

  /* Navigation */
  --nav:         #1E1C18;   /* Nav-Hintergrund (dunkel!) */
  --nav-border:  #2E2C28;

  /* Primärfarbe */
  --primary:     #2B5CE8;
  --primary-dim: rgba(43,92,232,0.09);
  --primary-hover: #1A4CD8;

  /* Semantische Farben */
  --green:       #1A9E58;   --green-dim: rgba(26,158,88,0.1);
  --amber:       #C87820;   --amber-dim: rgba(200,120,32,0.1);
  --blue:        #2B5CE8;   --blue-dim:  rgba(43,92,232,0.1);
  --purple:      #7448C8;   --purple-dim:rgba(116,72,200,0.1);
  --rose:        #D84060;   --rose-dim:  rgba(216,64,96,0.1);
  --teal:        #189E8A;   --teal-dim:  rgba(24,158,138,0.1);

  /* Tabellen */
  --row-hover:   rgba(0,0,0,0.025);
  --row-active:  rgba(43,92,232,0.07);
  --row-border:  rgba(0,0,0,0.07);
}
```

### Carbon (Dark Theme)

```css
[data-theme="carbon"] {
  /* Hintergründe */
  --bg:          #181818;   /* Page background — reines Dunkelgrau */
  --surface:     #212121;
  --surface-alt: #292929;
  --surface-hi:  #323232;

  /* Borders */
  --border:      #3E3E3E;
  --border-hi:   #4E4E4E;

  /* Typografie */
  --text:        #EBEBEB;
  --text-muted:  #888888;
  --text-subtle: #555555;

  /* Navigation */
  --nav:         #101010;
  --nav-border:  #282828;

  /* Primärfarbe */
  --primary:     #00C4B0;   /* Teal — markant, kein Blauton */
  --primary-dim: rgba(0,196,176,0.13);
  --primary-hover: #00AE9C;

  /* Semantische Farben */
  --green:       #4EC87A;   --green-dim: rgba(78,200,122,0.12);
  --amber:       #E8A030;   --amber-dim: rgba(232,160,48,0.12);
  --blue:        #4A88F5;   --blue-dim:  rgba(74,136,245,0.12);
  --purple:      #9A72F5;   --purple-dim:rgba(154,114,245,0.12);
  --rose:        #F06070;   --rose-dim:  rgba(240,96,112,0.12);
  --teal:        #00C4B0;   --teal-dim:  rgba(0,196,176,0.12);

  /* Tabellen */
  --row-hover:   rgba(255,255,255,0.025);
  --row-active:  rgba(0,196,176,0.08);
  --row-border:  rgba(255,255,255,0.05);
}
```

### Theme-Aktivierung

Das Theme wird via `data-theme` Attribut auf dem `<html>` oder `<body>` Element gesetzt:

```js
// Light
document.documentElement.setAttribute('data-theme', 'chalk');
// Dark
document.documentElement.setAttribute('data-theme', 'carbon');
```

---

## Typografie

```css
font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;

/* Seitenüberschrift */
font-size: 18px; font-weight: 700; letter-spacing: -0.02em;

/* Nav-Items */
font-size: 13px; font-weight: 400 / 600 (aktiv);

/* Tabellen-Header */
font-size: 10px; font-weight: 700; letter-spacing: 0.08em; text-transform: uppercase;

/* Tabelleninhalt */
font-size: 12–13px;

/* Labels (Formularfelder) */
font-size: 11px; font-weight: 600; letter-spacing: 0.04em;

/* Badges */
font-size: 10–11px; font-weight: 600; letter-spacing: 0.02em;
```

---

## Komponenten

### Navigation

```
Höhe: 46px
Hintergrund: var(--nav)
Border-bottom: 1px solid var(--nav-border)

Logo-Block links:
  - Icon: 24×24px, border-radius: 7px, bg: var(--primary-dim)
  - Wordmark: 14px, font-weight 700, color: var(--text)
  - Abstand zum ersten Nav-Item: 28px

Nav-Items:
  - Padding: 0 14px, Höhe: 46px
  - Aktiv: font-weight 600, color: var(--text), border-bottom: 2px solid var(--primary)
  - Inaktiv: font-weight 400, color: var(--text-muted), border-bottom: 2px solid transparent

Avatar rechts: 30×30px, border-radius: 50%, bg: var(--surface-hi)
```

### Status-Badges (Rechnungstabelle)

Alle Badges: `border-radius: 20px`, `font-size: 10px`, `font-weight: 600`, `padding: 2px 7px`

| Status | Hintergrund | Text | Border |
|---|---|---|---|
| Zahlung: offen | `var(--amber-dim)` | `var(--amber)` | `rgba(amber, 0.25)` |
| Zahlung: bezahlt | `var(--green-dim)` | `var(--green)` | `rgba(green, 0.25)` |
| Beihilfe: offen | `var(--rose-dim)` | `var(--rose)` | `rgba(rose, 0.25)` |
| Beihilfe: eingereicht | `var(--blue-dim)` | `var(--blue)` | `rgba(blue, 0.25)` |
| PKV: offen | `rgba(255,255,255,0.04)` | `var(--text-muted)` | `var(--border)` |
| PKV: eingereicht | `var(--teal-dim)` | `var(--teal)` | `rgba(teal, 0.25)` |

### Tabellen-Zeilen

```
Zeilen-Höhe: ca. 42px (padding: 10px 12px)
Hintergrund normal:   transparent
Hintergrund hover:    var(--row-hover)
Hintergrund aktiv:    var(--row-active)
Aktive Zeile:         border-left: 2px solid var(--primary)
Row-Separator:        border-bottom: 1px solid var(--row-border)

REF-Spalte (aktiv):   color: var(--primary), font-weight: 600
Betrag:               font-size: 13px, font-weight: 700, text-align: right,
                      font-variant-numeric: tabular-nums
Typ-Tag:              bg: var(--surface-hi), padding: 2px 8px, border-radius: 5px,
                      font-size: 11px, color: var(--text-muted)
```

### Detail-Panel (Rechnungsbearbeitung)

```
Breite: 440px (fest), flexshrink: 0
Hintergrund: var(--surface)
Border-left: 1px solid var(--border)
Öffnet sich beim Klick auf eine Tabellenzeile

Panel-Header:
  - bg: var(--surface-alt), padding: 14px 18px
  - REF: 11px, font-weight 600, color: var(--text-muted)
  - Betrag: 20px, font-weight 700
  - Schließen-Button: ✕, hover → bg: var(--surface-hi)

Tabs (Details / Anhänge / Anträge / Protokoll):
  - bg: var(--surface-alt)
  - Aktiver Tab: color: var(--primary), border-bottom: 2px solid var(--primary)
  - Inaktiver Tab: color: var(--text-muted)

Formular:
  - Padding: 16px 18px, gap: 14px
  - 2-Spalten-Grid für Feldpaare (gridTemplateColumns: 1fr 1fr, gap: 12px)
  - Trennlinie (border-top: 1px solid var(--border)) zwischen Abschnitten

Formularfelder:
  - bg: var(--bg)
  - border: 1px solid var(--border)
  - border-radius: 6px
  - padding: 7px 10px
  - font-size: 13px
  - Focus: border-color: var(--primary), box-shadow: 0 0 0 3px var(--primary-dim)
  - Select: custom Chevron-Icon rechts

Footer:
  - bg: var(--surface-alt), border-top: 1px solid var(--border), padding: 12px 18px
  - Speichern: bg: var(--primary), color: #fff, border-radius: 7px, padding: 8px 20px
  - Abbrechen: transparent, border: 1px solid var(--border), hover → bg: var(--surface-hi)
```

### Filter-Bar (Rechnungsseite)

```
Padding: 16px 24px 12px
Suchfeld: padding-left: 30px (Icon links eingebettet), width: 180px
Filter-Chips: bg: var(--surface), border: 1px solid var(--border), padding: 5px 12px,
              border-radius: 6px, font-size: 12px
Neu-Button: bg: var(--primary), color: #fff, border-radius: 7px, padding: 6px 14px
```

---

## Dashboard-Spezifika

### Stat-Karten

Jede Karte enthält drei Ebenen:
1. **Label** (10px) + **Aufgaben-Badge** (9px) oben rechts — nur wenn Aufgaben vorhanden
2. **Betrag** (15–17px, font-weight 700, letter-spacing: -0.02em)
3. **Anzahl Rechnungen** (9–10px, opacity 0.5–0.6)

```
padding: 10–12px 12–14px
border-radius: 8px
Jede Karte hat eine eigene Farb-Identität (bg + border + text + val):
```

#### Chalk — Stat-Karten Farben

| Karte | bg | border | text | val |
|---|---|---|---|---|
| Offen | `#FEF5E4` | `#C87820` | `#7A4A08` | `#A06010` |
| Bezahlt | `#EDFBF3` | `#1A9E58` | `#0D6B3C` | `#0A5A30` |
| Beihilfe ausst. | `#EEF3FE` | `#2B5CE8` | `#1A3B9E` | `#1430A0` |
| Beihilfe erst. | `#F3EFFE` | `#7448C8` | `#4A2898` | `#3E208A` |
| PKV ausst. | `#EDFBF8` | `#189E8A` | `#0C6A5E` | `#0A5A4E` |
| PKV erst. | `#F5F3F0` | `#C2BAB2` | `#6A6258` | `#4A4240` |

#### Carbon — Stat-Karten Farben

| Karte | bg | border | text | val |
|---|---|---|---|---|
| Offen | `#1E1A12` | `#B07820` | `#E8A030` | `#F0B040` |
| Bezahlt | `#101E14` | `#2EA060` | `#4EC87A` | `#5ED888` |
| Beihilfe ausst. | `#101828` | `#3A70E0` | `#4A88F5` | `#6098F8` |
| Beihilfe erst. | `#18101E` | `#7A52D8` | `#9A72F5` | `#AA82FF` |
| PKV ausst. | `#0E1A18` | `#00A090` | `#00C4B0` | `#00D4C0` |
| PKV erst. | `#1E1E1E` | `#4E4E4E` | `#888888` | `#AAAAAA` |

### Dashboard-Sektionen (Rechnungslisten)

Drei Sektionen mit eigener Farbidentität: **Zu bezahlen** (Amber), **Beihilfe einreichen** (Blau), **Warten auf Bescheid** (Lila).

```
border-radius: 8px
Sektion-Header: padding: 8–10px 14px, font-weight 700, font-size 12–13px
Zeilen: padding: 6–8px 14px, border-top: 1px solid var(--rowBorder)
Betrag: font-size 13px, font-weight 700, min-width: 74–80px, text-align: right

Button-Hierarchie:
  Primär (Bezahlt markieren): bg: btnPaid-Farbe, color: #fff, filled
  Sekundär (Eingereicht):     transparent, border: 1.5px solid btnColor, outlined
```

### Rückerstattungs-Fortschrittsbalken

```
Höhe: 6px, border-radius: 4px
Track: var(--progressBg)  →  Chalk: #E4DED6 / Carbon: #3E3E3E
Fill:  var(--progressFill) →  Chalk: #C87820 / Carbon: #E8A030
```

---

## Interaktionen & Verhalten

### Tabelle
- **Klick auf Zeile** → Detail-Panel öffnet sich rechts (width: 440px), Tabelle wird schmaler
- **Klick auf ✕ im Panel** oder erneuter Klick auf aktive Zeile → Panel schließt sich
- **Hover auf Zeile** → `var(--row-hover)` Hintergrund
- **Checkbox** → stopPropagation, öffnet kein Panel

### Detail-Panel
- Öffnet ohne Animation (oder subtile slide-in von rechts, 150ms ease-out)
- Tabs ohne eigenes Routing — rein lokaler State
- Speichern/Abbrechen: Hover-State auf Buttons

### Filter-Bar
- Kollabierbar: Zeigt nur "N aktiv"-Badge wenn zugeklappt
- Ausgeklappt: Filter-Chips + Datumseingaben sichtbar

---

## Schatten & Radien

```
Karten/Panels: border-radius: 8px
Buttons: border-radius: 6–7px
Badges: border-radius: 20px
Nav-Icon: border-radius: 7px
Avatar: border-radius: 50%

Schatten (Chalk):
  Tabellenkopf sticky: kein Shadow, nur border-bottom
  Panel: kein Shadow, nur border-left

Scrollbar:
  width: 6px
  thumb: var(--border-hi)
  track: transparent
```

---

## Theme-Umschaltung in der App

```js
// Systemeinstellung auslesen und Theme setzen
const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
document.documentElement.setAttribute('data-theme', prefersDark ? 'carbon' : 'chalk');

// Manueller Toggle
function setTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  localStorage.setItem('pkv-theme', theme);
}

// Beim App-Start
const saved = localStorage.getItem('pkv-theme');
setTheme(saved || (prefersDark ? 'carbon' : 'chalk'));
```

---

## Assets & Icons

- **Nav-Icon**: Einfaches SVG-Pictogram (Rechtecke die Dokumente/Karten symbolisieren) — kann durch bestehendes App-Icon ersetzt werden
- **Chevron für Select-Felder**: SVG Data-URL in CSS, kann durch Icon-Library ersetzt werden
- **Sortier-Pfeile in Tabellen-Headern**: `↕` Unicode-Zeichen, besser durch Icon-Komponente ersetzen

---

## Dateien in diesem Paket

```
design_handoff_pkv_themes/
├── README.md                   ← diese Datei
├── PKV Theme Proposal.html     ← Dashboard: Chalk vs. Carbon Vergleich
└── Rechnungen.html             ← Rechnungstabelle mit Detail-Panel
```

Um die Referenz-Designs zu öffnen: HTML-Datei im Browser öffnen. `Rechnungen.html` hat einen Tweaks-Button oben rechts zum Theme-Wechseln.
